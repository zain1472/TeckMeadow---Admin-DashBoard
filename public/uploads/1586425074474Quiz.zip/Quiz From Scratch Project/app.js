var nameForm = document.getElementById("name");
var username = "";
// all questions
var textQuestions = [
  {
    title: "Is China a free country?",
    answer: "yes"
  },
  {
    title: "Is USA a free country?",
    answer: "yes"
  }
];
var numberQuestions = [
  {
    title: "What is 5 + 5",
    answer: 10
  },
  {
    title: "What is 3 + 7",
    answer: 10
  },
  {
    title: "What is 2 * 5",
    answer: 10
  },
  {
    title: "What is 1 * 10",
    answer: 10
  }
];
var imageQuestions = [
  {
    title: "Which one of the following is a mercedes?",
    answer: 2
  },
  {
    title: "Which one of the following is an audi?",
    answer: 1
  }
];
var radioQuestions = [
  {
    title: "Is Avengers a movie?",
    answer: "yes"
  },
  {
    title: "Is Conjuring a movie?",
    answer: "yes"
  }
];
var currentQuestion = 0;
var score = [false, false, false, false, false];
// handel the form submit
nameForm.addEventListener("submit", function(e) {
  e.preventDefault();
  if (currentQuestion === 0) {
    var nameInput = document.getElementById("nameInput");
    username = nameInput.value;
    nameInput.required = false;
    document.querySelector("div").classList.add("none");
    var nextButton = document.querySelector("#next");
    var prevButton = document.querySelector("#previous");
    nextButton.classList.remove("none");
    prevButton.classList.remove("none");
    document.querySelector("#next").addEventListener("click", function() {
      loadNextQuestion();
    });
    prevButton.addEventListener("click", function() {
      loadPreviousQuestion();
    });
    document.querySelector("#submitButton").innerText = "Enter";
    loadNextQuestion();
  } else if (currentQuestion === 1) {
    if (document.querySelector("#first").value.toLowerCase() === "yes") {
      score[currentQuestion - 1] = true;
    }
    loadNextQuestion();
  } else if (currentQuestion === 3) {
    if (document.querySelector("#radio1").checked) {
      score[currentQuestion - 1] = true;
    }
    loadNextQuestion();
  } else if (currentQuestion === 4) {
    if (
      document.querySelector("#fourth").value === "ten" ||
      document.querySelector("#fourth").value === "10"
    ) {
      score[currentQuestion - 1] = true;
    }
    loadNextQuestion();
  } else if (currentQuestion === 5) {
    if (
      document.querySelector("#fifth").value === "ten" ||
      document.querySelector("#fourth").value === "10"
    ) {
      score[currentQuestion - 1] = true;
    }
    loadNextQuestion();
  }

  console.log(username);
});
const questions = [];
// load random questions
function loadRandomQuestons() {
  for (let index = 1; index <= 5; index++) {
    console.log(index);
    if (index === 1) {
      let i = Math.round(Math.random() * 1);
      questions.push(textQuestions[i]);
    } else if (index === 2) {
      let i = Math.round(Math.random() * 1);
      questions.push(imageQuestions[i]);
    } else if (index === 3) {
      let i = Math.round(Math.random() * 1);
      questions.push(radioQuestions[i]);
    } else {
      let i = Math.round(Math.random() * 3);
      questions.push(numberQuestions[i]);
    }
  }
  questions.forEach((question, key) => {
    if (key === 0) {
      document.querySelector("#firstQuestion").innerText = question.title;
    } else if (key === 1) {
      document.querySelector("#secondQuestion").innerText = question.title;
      if (question.title === "Which one of the following is a mercedes?") {
        document.querySelectorAll("img")[0].src = "./mercedes1.jpg";
        document.querySelectorAll("img")[1].src = "./mercedes2.jpg";
        document.querySelectorAll("img")[2].src = "./mercedes3.jpg";
      } else {
        document.querySelectorAll("img")[0].src = "./audi1.jpg";
        document.querySelectorAll("img")[1].src = "./audi2.jpg";
        document.querySelectorAll("img")[2].src = "./audi3.jpg";
      }
    } else if (key === 2) {
      document.querySelector("#thirdQuestion").innerText = question.title;
    } else if (key === 3) {
      document.querySelector("#fourthQuestion").innerText = question.title;
    } else {
      document.querySelector("#fifthQuestion").innerText = question.title;
    }
  });
}
// previous question
function loadNextQuestion() {
  if (currentQuestion < 6) {
    currentQuestion++;
    var questions = document.querySelectorAll("div");
    questions[currentQuestion - 1].classList.add("none");
    questions[currentQuestion].classList.remove("none");
  }
  if (currentQuestion === 6) {
    displayScore();
  }
}
// next button
function loadPreviousQuestion() {
  if (currentQuestion > 1) {
    var questions = document.querySelectorAll("div");
    questions[currentQuestion].classList.add("none");
    questions[currentQuestion - 1].classList.remove("none");
    currentQuestion--;
  }
}
// answer the question with the image
function answerImageQuestion(answer) {
  if (answer === 2) {
    score[1] = true;
  }
  loadNextQuestion();
}

// when all questions are answered this function shows the score
function displayScore() {
  let Score = 0;
  score.forEach(s => {
    if (s) {
      Score += 20;
    }
  });
  document.querySelector("#congratulations").innerText =
    "Congratulations " + " " + username;
  document.querySelector("#totalScore").innerText = "You scored " + Score + "%";
}
